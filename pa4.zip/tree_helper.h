int build_tree_binary(char* infile, char * outfile);
int build_tree_e(char* infile, char* outfile);
void treeTraversal(Tnode *node);