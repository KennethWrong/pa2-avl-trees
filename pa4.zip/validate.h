int check_balanced(Tnode *node);
int check_if_bst(Tnode *node);